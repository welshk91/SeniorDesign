/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) Kevin Welsh 2011 <welshkev@mail.gvsu.edu>
	 * 
 test is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
	 * 
	 * test is distributed in the hope that it will be useful, but
	 * WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	 * See the GNU General Public License for more details.
	 * 
	 * You should have received a copy of the GNU General Public License along
	 * with this program.  If not, see <http://www.gnu.org/licenses/>.
	 */

#include <config.h>		//used for autoconf
#include <gtk/gtk.h>	//interface
#include <glib/gi18n.h> //internationalization
#include <stdio.h>
#include <stdlib.h>

/* For testing propose use the local (not installed) ui file */
/* #define UI_FILE PACKAGE_DATA_DIR"/test/ui/test.ui" */
#define UI_FILE "src/test.ui"
#define FRAME_SIZE 512
#define NUMBER_OF_FRAMES 8

/*Global Variables*/
/*Tool bar*/
GtkWidget *Status;
GtkWidget *Command;
/*Physical Memory*/
GtkWidget *PM;
GtkWidget *pm0;
GtkWidget *pm1;
GtkWidget *pm2;
GtkWidget *pm3;
GtkWidget *pm4;
GtkWidget *pm5;
GtkWidget *pm6;
GtkWidget *pm7;
/*Virtual Memory*/
GtkWidget *VM;
GtkWidget *vm0;
GtkWidget *vm1;
GtkWidget *vm2;
GtkWidget *vm3;
GtkWidget *vm4;
GtkWidget *vm5;
GtkWidget *vm6;
GtkWidget *vm7;
/*Status Message array*/
char bufStatus[128];
/*Page Table*/
GtkWidget *notebook;
GtkWidget *PT;
int pages = 4;
int NUMBER_OF_PAGES = 8;

/* Signal handlers */
/* Note: These may not be declared static because signal autoconnection
 * only works with non-static methods
 */

/* Called when the window is closed */
void
destroy (GtkWidget *widget, gpointer data)
{
	gtk_main_quit ();
}

/*Handles Halt*/
void haltting(int p){
	/*Delete from Virtual*/
	int h;
	GtkWidget *r;
	char temp2[64];

	/*Loop through memory and delete entries*/
	for(h=0;h<NUMBER_OF_PAGES;h++){
		/*Handles what label is being modified*/
		switch(h){
			case 0:
				r=vm0;
				break;
			case 1:
				r=vm1;
				break;
			case 2:
				r=vm2;
				break;
			case 3:
				r=vm3;
				break;
			case 4:
				r=vm4;
				break;
			case 5:
				r=vm5;
				break;
			case 6:
				r=vm6;
				break;
			case 7:
				r=vm7;
				break;
			default:
				r=vm0;
				break;
		}//end switch

		const gchar* t = gtk_label_get_label (GTK_LABEL(r));
		char buf1[32];
		char buf2[32];
		sprintf(buf1,"P%d Text",p);
		sprintf(buf2,"P%d Data",p);

		/*Delete process Text and Data*/
		if(g_str_equal (t, _(buf1)) || g_str_equal (t, _(buf2))){
			sprintf(temp2,"--");
			gtk_label_set_text (GTK_LABEL(r),temp2);
		}
		else if(h==(NUMBER_OF_PAGES-1)){
			/*Done*/
			sprintf(bufStatus,"Process %d Removed from Virtual Memory",p);
			gtk_label_set_text (GTK_LABEL(Status), bufStatus);
		}
	}
	
	/*Delete from Physical*/
	int i;
	GtkWidget *s;
	char temp[64];

	/*Loop through memory and delete entries*/
	for(i=0;i<NUMBER_OF_FRAMES;i++){
		/*Handles what label is being modified*/
		switch(i){
			case 0:
				s=pm0;
				break;
			case 1:
				s=pm1;
				break;
			case 2:
				s=pm2;
				break;
			case 3:
				s=pm3;
				break;
			case 4:
				s=pm4;
				break;
			case 5:
				s=pm5;
				break;
			case 6:
				s=pm6;
				break;
			case 7:
				s=pm7;
				break;
			default:
				s=pm0;
				break;
		}//end switch

		const gchar* t = gtk_label_get_label (GTK_LABEL(s));
		char buf1[32];
		char buf2[32];
		sprintf(buf1,"P%d Text",p);
		sprintf(buf2,"P%d Data",p);

		/*Delete process Text and Data*/
		if(g_str_equal (t, _(buf1)) || g_str_equal (t, _(buf2))){
			sprintf(temp,"--");
			gtk_label_set_text (GTK_LABEL(s),temp);

			/*Set Resident Bit False*/
			GtkWidget *y = gtk_grid_get_child_at (GTK_GRID(PT),3,i+1);
			gtk_label_set_text (GTK_LABEL(y)," ");
			gtk_widget_show_all (PT);

			/*Set Valid Bit False*/
			GtkWidget *z = gtk_grid_get_child_at (GTK_GRID(PT),2,i+1);
			gtk_label_set_text (GTK_LABEL(z)," ");
			gtk_widget_show_all (PT);
		}
		else if(i==(NUMBER_OF_FRAMES-1)){
			/*Done*/
			sprintf(bufStatus,"Process %d Removed from Physical Memory",p);
			gtk_label_set_text (GTK_LABEL(Status), bufStatus);
		}

	}//end i loop
}

/*Handles Next function*/
void
next(GtkWidget *widget)
{
	int process=0;
	int text=0;
	int data=0;
	int halt=0;

	/*Get User Command*/
	const gchar* c = gtk_entry_get_text (GTK_ENTRY(Command));
	printf("Command: %s\n",c);

	/*Parse Command*/
	int count=0;
	char *tmp;
	tmp=strtok(c," ");
	while(tmp!=NULL){
		if(count==0){
			process=atoi(tmp);
			printf("Process is %d\n",process);
		}
		else if(count==1){
			text=atoi(tmp);
			if(strcmp(tmp,"Halt")==0){
				printf("HALT\n");
				halt=1;
			}
			else{
				printf("Text is %d\n",text);
			}
		}
		else if(count==2 && (halt==0)){
			data=atoi(tmp);
			printf("Data is %d\n",data);
		}

		tmp=strtok(NULL," ");
		count++;
	}

	/*If Halt is true*/
	if(halt==1){
		haltting(process);
	}

	else{

		/*Make New Page Table - Doesn't Work*/
		//gtk_notebook_insert_page (GTK_NOTEBOOK(notebook),NULL,NULL,process+1);
		
		/*Calculate frames & pages needed*/
		int tFrames = text/FRAME_SIZE;
		int dFrames = data/FRAME_SIZE;
		int tPages = text/FRAME_SIZE;
		int dPages = data/FRAME_SIZE;
		/*Add an extra page to store remainder*/
		if(text%FRAME_SIZE!=0){
			tFrames = tFrames + 1;
			tPages = tPages + 1;
		}

		if(data%FRAME_SIZE!=0){
			dFrames = dFrames + 1;
			dPages = dPages + 1;
		}

		int tLeft2 = tPages;
		int dLeft2 = dPages;

		int tLeft = tFrames;
		int dLeft = dFrames;

		/*Display Frames Needed*/
		sprintf(bufStatus,"Number of Text Frames:%d, Number of Data Frames:%d",tFrames,dFrames);
		gtk_label_set_text (GTK_LABEL(Status), bufStatus);


		/*Handles Virtual Memory Allocation*/
		GtkWidget *r; //place-holder for Virtual Memory Label
		char temp[64];
		int h;
		int j;
		GtkWidget *e1;
		
		for(j=0;j<(tPages+dPages);j++){
			for(h=0;h<NUMBER_OF_PAGES;h++){
				switch(h){
					case 0:
						r=vm0;
						break;
					case 1:
						r=vm1;
						break;
					case 2:
						r=vm2;
						break;
					case 3:
						r=vm3;
						break;
					case 4:
						r=vm4;
						break;
					case 5:
						r=vm5;
						break;
					case 6:
						r=vm6;
						break;
					case 7:
						r=vm7;
						break;
					default:
						r=e1;
						break;
				}//end switch

				const gchar* t = gtk_label_get_label (GTK_LABEL(r));
				if(g_str_equal (t, _("--"))){
					if(tLeft2!=0){
						sprintf(temp,"P%d Text", process);
						tLeft2 = tLeft2-1;
					}
					else if(dLeft2!=0){
						sprintf(temp,"P%d Data", process);
						dLeft2 = dLeft2-1;
					}
					else{
						sprintf(temp,"ERROR:Line 311");
					}

					/*Insert in Physical Memory*/
					gtk_label_set_text (GTK_LABEL(r),temp);

					/*Set Resident Bit True*/
					gtk_notebook_set_current_page(GTK_NOTEBOOK(notebook),2);
					GtkWidget *y = gtk_label_new ("Y");
					gtk_grid_attach (GTK_GRID(PT),y,3,h+1,1,1);
					gtk_widget_show_all (notebook);

					/*Set Valid Bit True*/
					gtk_notebook_set_current_page(GTK_NOTEBOOK(notebook),process+1);
					GtkWidget *z = gtk_label_new ("Y");
					gtk_grid_attach (GTK_GRID(PT),z,2,h+1,1,1);
					gtk_widget_show_all (notebook);
					break;

				}//end if

				else if(h==(NUMBER_OF_PAGES-1)){
					//sprintf(bufStatus,"No Virtual Memory Left");
					//printf("Make New Row %d\n",NUMBER_OF_PAGES);
					
					/*Expand Virtual Memory - Doesn't Work Correctly*/
					gtk_grid_insert_row (GTK_GRID(VM),NUMBER_OF_PAGES);
					GtkWidget *e = gtk_label_new ("Extra");
					e1 = gtk_label_new ("--");
					gtk_grid_attach (GTK_GRID(VM),e,0,NUMBER_OF_PAGES,1,1);
					gtk_grid_attach (GTK_GRID(VM),e1,1,NUMBER_OF_PAGES,1,1);
					NUMBER_OF_PAGES=NUMBER_OF_PAGES+1;
					gtk_widget_show_all (VM);
					break;
				}
			}//end h loop
		}//end j loop


		/*Physical Memory Allocation*/
		GtkWidget *s; //place-holder for Physical Memory
		char temp2[64];
		int i;
		int k;

		for(k=0;k<(tFrames+dFrames);k++){
			for(i=0;i<NUMBER_OF_FRAMES;i++){
				/*Handles what label is being modified*/
				switch(i){
					case 0:
						s=pm0;
						break;
					case 1:
						s=pm1;
						break;
					case 2:
						s=pm2;
						break;
					case 3:
						s=pm3;
						break;
					case 4:
						s=pm4;
						break;
					case 5:
						s=pm5;
						break;
					case 6:
						s=pm6;
						break;
					case 7:
						s=pm7;
						break;
					default:
						s=pm0;
						break;
				}//end switch

				/*if label is empty, insert value*/
				const gchar* t = gtk_label_get_label (GTK_LABEL(s));
				if(g_str_equal (t, _("--"))){

					if(tLeft!=0){
						sprintf(temp2,"P%d Text", process);
						tLeft = tLeft-1;
					}
					else if(dLeft!=0){
						sprintf(temp2,"P%d Data", process);
						dLeft = dLeft-1;
					}
					else{
						sprintf(temp2,"ERROR:Line 314");
					}

					gtk_label_set_text (GTK_LABEL(s),temp2);
					break;

				}//end if

				else if(i==(NUMBER_OF_FRAMES-1)){
					/*No Free Frames Available*/
					sprintf(bufStatus,"No Physical Memory Left");
					gtk_label_set_text (GTK_LABEL(Status), bufStatus);
				}
			}//end i loop
		}//end k loop

	}//end else
	gtk_entry_set_text (GTK_ENTRY(Command),"");

}//end next method

/*Main method sets-up interface, hands work off to next method*/
int
main (int argc, char *argv[])
{

	/*Used to connect to the ui file*/
	GtkBuilder *builder;
	GError* error = NULL;

	/*Main Window*/
	GtkWidget *window;

	/*Toolbar and Items*/
	GtkWidget *toolbar;
	GtkWidget *Next;

	/*Handles internationalization*/
#ifdef ENABLE_NLS
	bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
	bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
	textdomain (GETTEXT_PACKAGE);
#endif

	gtk_init (&argc, &argv);

	/*Set-up interface from ui file*/
	builder = gtk_builder_new ();
	if (!gtk_builder_add_from_file (builder, UI_FILE, &error))
	{
		g_critical ("Couldn't load builder file: %s", error->message);
		g_error_free (error);
	}

	/*Set-up Window*/
	window = GTK_WIDGET(gtk_builder_get_object (builder,"winMain"));
	gtk_builder_connect_signals (builder,NULL);

	/*Set-up Toolbar*/
	toolbar = GTK_WIDGET(gtk_builder_get_object (builder,"toolbar1"));
	Command = GTK_WIDGET(gtk_builder_get_object (builder,"entryCommand"));
	Next = GTK_WIDGET(gtk_builder_get_object (builder,"tbNext"));
	Status = GTK_WIDGET(gtk_builder_get_object (builder,"lbStatus"));

	/*Set-up Virtual Memory*/
	VM = GTK_WIDGET(gtk_builder_get_object (builder,"gridVM"));
	vm0 = GTK_WIDGET(gtk_builder_get_object (builder,"VM0"));
	vm1 = GTK_WIDGET(gtk_builder_get_object (builder,"VM1"));
	vm2 = GTK_WIDGET(gtk_builder_get_object (builder,"VM2"));
	vm3 = GTK_WIDGET(gtk_builder_get_object (builder,"VM3"));
	vm4 = GTK_WIDGET(gtk_builder_get_object (builder,"VM4"));
	vm5 = GTK_WIDGET(gtk_builder_get_object (builder,"VM5"));
	vm6 = GTK_WIDGET(gtk_builder_get_object (builder,"VM6"));
	vm7 = GTK_WIDGET(gtk_builder_get_object (builder,"VM7"));

	/*Set-up Physical Memory*/
	PM = GTK_WIDGET(gtk_builder_get_object (builder,"gridPM"));
	pm0 = GTK_WIDGET(gtk_builder_get_object (builder,"PM0"));
	pm1 = GTK_WIDGET(gtk_builder_get_object (builder,"PM1"));
	pm2 = GTK_WIDGET(gtk_builder_get_object (builder,"PM2"));
	pm3 = GTK_WIDGET(gtk_builder_get_object (builder,"PM3"));
	pm4 = GTK_WIDGET(gtk_builder_get_object (builder,"PM4"));
	pm5 = GTK_WIDGET(gtk_builder_get_object (builder,"PM5"));
	pm6 = GTK_WIDGET(gtk_builder_get_object (builder,"PM6"));
	pm7 = GTK_WIDGET(gtk_builder_get_object (builder,"PM7"));

	/*Set-up Page Table - Not implemented correctly, each process needs own table*/
	notebook = GTK_WIDGET(gtk_builder_get_object (builder,"notebookPT"));
	int i;
	for(i=0;i<pages;i++){

		/*Labels for page table*/
		GtkWidget *p;
		GtkWidget *f;
		GtkWidget *vb;
		GtkWidget *rb;
		GtkWidget *da;
		GtkWidget *zero;
		GtkWidget *one;
		GtkWidget *two;
		GtkWidget *three;
		GtkWidget *four;
		GtkWidget *five;
		GtkWidget *six;
		GtkWidget *seven;

		/*label text*/
		char bufp[10];
		char buff[10];
		char bufvb[10];
		char bufrb[10];
		char bufda[10];
		char buf0[10];
		char buf1[10];
		char buf2[10];
		char buf3[10];
		char buf4[10];
		char buf5[10];
		char buf6[10];
		char buf7[10];

		/*Initialize Grid*/
		PT = gtk_grid_new();
		gtk_grid_set_column_spacing (GTK_GRID(PT),5);
		gtk_grid_set_row_spacing (GTK_GRID(PT),5);

		/*Make grid 5*9*/
		gtk_grid_insert_column (GTK_GRID(PT),0);
		gtk_grid_insert_row (GTK_GRID(PT),0);
		gtk_grid_insert_column (GTK_GRID(PT),1);
		gtk_grid_insert_row (GTK_GRID(PT),1);
		gtk_grid_insert_column (GTK_GRID(PT),2);
		gtk_grid_insert_row (GTK_GRID(PT),2);
		gtk_grid_insert_column (GTK_GRID(PT),3);
		gtk_grid_insert_row (GTK_GRID(PT),3);
		gtk_grid_insert_column (GTK_GRID(PT),4);
		gtk_grid_insert_row (GTK_GRID(PT),4);
		gtk_grid_insert_row (GTK_GRID(PT),5);
		gtk_grid_insert_row (GTK_GRID(PT),6);
		gtk_grid_insert_row (GTK_GRID(PT),7);
		gtk_grid_insert_row (GTK_GRID(PT),8);

		/*Label Text*/
		sprintf(bufp, "Page");
		sprintf(buff, "Frame");
		sprintf(bufvb, "Valid");
		sprintf(bufrb, "Res");
		sprintf(bufda, "Disk");
		sprintf(buf0, "0");
		sprintf(buf1, "1");
		sprintf(buf2, "2");
		sprintf(buf3, "3");
		sprintf(buf4, "4");
		sprintf(buf5, "5");
		sprintf(buf6, "6");
		sprintf(buf7, "7");

		/*Create Labels*/
		p = gtk_label_new (bufp);
		f = gtk_label_new (buff);
		vb = gtk_label_new (bufvb);
		rb = gtk_label_new (bufrb);
		da = gtk_label_new (bufda);
		zero = gtk_label_new (buf0);
		one = gtk_label_new (buf1);
		two = gtk_label_new (buf2);
		three = gtk_label_new (buf3);
		four = gtk_label_new (buf4);
		five = gtk_label_new (buf5);
		six = gtk_label_new (buf6);
		seven = gtk_label_new (buf7);

		/*Add labels*/
		gtk_grid_attach (GTK_GRID(PT),p,0,0,1,1);
		gtk_grid_attach (GTK_GRID(PT),f,1,0,1,1);
		gtk_grid_attach (GTK_GRID(PT),vb,2,0,1,1);
		gtk_grid_attach (GTK_GRID(PT),rb,3,0,1,1);
		gtk_grid_attach (GTK_GRID(PT),da,4,0,1,1);

		gtk_grid_attach (GTK_GRID(PT),zero,0,1,1,1);
		gtk_grid_attach (GTK_GRID(PT),one,0,2,1,1);
		gtk_grid_attach (GTK_GRID(PT),two,0,3,1,1);
		gtk_grid_attach (GTK_GRID(PT),three,0,4,1,1);
		gtk_grid_attach (GTK_GRID(PT),four,0,5,1,1);
		gtk_grid_attach (GTK_GRID(PT),five,0,6,1,1);
		gtk_grid_attach (GTK_GRID(PT),six,0,7,1,1);
		gtk_grid_attach (GTK_GRID(PT),seven,0,8,1,1);
		
		/*Add a page to notebook*/
		gtk_notebook_append_page (GTK_NOTEBOOK(notebook),PT,NULL);

		gtk_widget_show(PT);
		gtk_widget_show_all (window);

	}//End page table

	gtk_widget_show (window);

	/*Connect Next button with 'next' function*/
	g_signal_connect(Next,"clicked",G_CALLBACK(next),NULL);

	gtk_main ();
	return 0;
}